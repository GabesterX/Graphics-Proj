UV's may be skewed in a few places a bit since I had to manually fix a lot of them, but it shouldn't be too bad. In addition, some materials such as the ones for the stars, the bushes and the front fencing may needed to be mirrored, tiled at 0.5, and offset at 0.5 since neither .mtl nor .dae fully supports these material settings.

Other than that, enjoy the rip!